<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="index.php">home</a>
         <a href="about.php">about</a>
         <a href="shop.php">shop</a>
         <a href="contact.php">contact</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> 065674300 </p>
         <p> <i class="fas fa-phone"></i> 065674355 </p>
         <p> <i class="fas fa-envelope"></i> cloudcore@cc.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Jln Datuk Mohammad Musa, 94300 Kota Samarahan, Sarawak </p>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href=""> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href=""> <i class="fab fa-twitter"></i> twitter </a>
         <a href=""> <i class="fab fa-instagram"></i> instagram </a>
         <a href=""> <i class="fab fa-youtube"></i> youtube </a>
      </div>

   </div>

   <p class="credit"> © Copyright 2023 <span>cloudcore.com</span> All rights reserved.</p>

</section>
