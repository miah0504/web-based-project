MAXIMOFF (CLOUDCORE WEB HOSTING)

i. url of group prototype (http://cloudcore.infinityfreeapp.com/)
