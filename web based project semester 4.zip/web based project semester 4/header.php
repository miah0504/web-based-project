<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<header class="header">

   <div class="header-2">
      <div class="flex">
         <img src="img/logo.png" class="logo" alt="" style="position: relative; left:1%; width: 10%; height: 100%; object-fit: cover; object-position: 50% 50%">

         <nav class="navbar" style="height: fixed ">
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="shop.php">Shop</a>
            <a href="contact.php">Contact</a>
            <?php
            if(isset($_SESSION['user_id'])){
              echo "<a href='orders.php'>orders</a>";
            }
             ?>
         </nav>

         <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <a href="shop.php" class="fas fa-search"></a>
            <div id="user-btn" class="fas fa-user"></div>
            <?php
            $cart_rows_number=0;
            if(isset($_SESSION['user_id'])){
              $select_cart_number = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
              $cart_rows_number = mysqli_num_rows($select_cart_number);
            }
            ?>
            <a href="cart.php"> <i class="fas fa-shopping-cart"></i> <span>(<?php echo $cart_rows_number; ?>)</span> </a>
         </div>


         <div class="user-box">
           <?php
           if(isset($_SESSION['user_id'])){
             echo "<p>username : <span> " . $_SESSION['user_name'] ." </span></p>";
             echo "<p>email : <span> " . $_SESSION['user_email'] . " </span></p>";
             echo "<a href='logout.php' class='delete-btn'>logout</a>";
           }else{
             echo "<p>new <a href='login.php'>login</a> | <a href='register.php'>register</a></p>";
           }
           ?>
         </div>
      </div>
   </div>

</header>
