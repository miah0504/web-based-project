<?php

include 'config.php';

session_start();
if(isset($_SESSION['user_id'])){
  $user_id = $_SESSION['user_id'];
}else{
  $user_id =0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <link rel="icon" href="img/title logo.png" type="image/icon type">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'header.php'; ?>

<div class="heading">
   <h3>About Us</h3>
   <p> <a href="index.php">home</a> / about </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="img/whychoose.jpg" alt="">
      </div>

      <div class="content">
         <h3>Lightning-Fast Speed</h3>
         <p>We understand the importance of speed in today's digital age. With our cutting-edge infrastructure and optimized servers, we guarantee blazing-fast loading times for your website, ensuring a smooth user experience and higher search engine rankings.</p>
         <h3>24/7 Customer Support</h3>
         <p>We take pride in our exceptional customer support team that is available 24/7 to assist you with any queries or technical difficulties you may encounter. Our knowledgeable experts are ready to provide personalized solutions and guidance to ensure your hosting experience is smooth and stress-free.</p>
         <h3>Feature-Rich Hosting Plans</h3>
         <p>From shared hosting to dedicated servers, we offer a range of hosting plans tailored to meet the unique needs of different businesses and individuals. Each plan comes bundled with an array of features and resources, providing you with the tools necessary to create and manage your online presence effectively.</p>

         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
