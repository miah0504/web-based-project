<?php

include 'config.php';

session_start();
if(isset($_SESSION['user_id'])){
  $user_id = $_SESSION['user_id'];
}else{
  $user_id =0;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" href="img/title logo.png" type="image/icon type">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device=-width, intial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/faq.css">
    <title>FAQ's</title>
  </head>

  <body>
    <?php include 'header.php'; ?>

    <h2 class="product-category">Frequently Asked Question</h2>

    <div class="centerplease">Web Hosting</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question1" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question1" class="question">
        What level of customer support is provided?
        </label>
        <div class="answers">
        We offer 24/7 customer support through multiple channels like live chat, phone, and email. We also read reviews and try our best to response to ensure our service quality good.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question2" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question2" class="question">
        How often are backups performed?
        </label>
        <div class="answers">
        The frequency of backups varies with user options. Some perform daily backups, while others may offer weekly or monthly backups. 
        </div>
      </div>

      <div>
        <input type="checkbox" id="question3" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question3" class="question">
        Can I transfer my website from one hosting provider to another?
        </label>
        <div class="answers">
        Yes, We allow website transfers. You can either do it manually by moving your files and databases or use automated migration tools provided by the hosting company.
        </div>
      </div>
    </div>

    

    <footer id="contact"></footer>

    <?php include 'footer.php'; ?>

  </body>
</html>
