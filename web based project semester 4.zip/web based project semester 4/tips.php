<?php

include 'config.php';

session_start();
if(isset($_SESSION['user_id'])){
  $user_id = $_SESSION['user_id'];
}else{
  $user_id =0;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device=-width, intial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/faq.css">
    <title>Tips</title>
  </head>

  <body>

    <?php include 'header.php'; ?>

    <h2 class="product-category">My TOP TIPS!</h2>

    <div class="centerplease">I give you some good tips for grabbing that cheap new car you are looking for! You can trust me -I am Ling!</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question1" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question1" class="question">
          Tip: Leasing company website price VAT scam trick
        </label>
        <div class="answers">
          It is so unfair to my private customers and to me, how many other UK Car Leasing companies illegally advertise and display prices on their websites, advertising and marketing. My local Trading Standards authority has been helping me with this massively unsatisfactory situation. When British consumers click onto most car leasing and contract hire sites, they are shown prices that are deliberately meant to deceive and confuse. The prices are deliberately meant to make cars appear cheaper than they really are (by showing them ex VAT). According to Gateshead Trading Standards, The Pricing Practices Guide made under the "Consumer Protection from Unfair Trading Regulations 2008" requires that: 'All price indications you give to consumers, by whatever means, should include VAT. This total price must be displayed prominently so that consumers can see it. Prices may ONLY be indicated exclusive of VAT at an outlet or through advertisements from which ALL of your business is with business customers.'
        </div>
      </div>

      <div>
        <input type="checkbox" id="question2" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question2" class="question">
          Tip: If you see the car you want; Jump
        </label>
        <div class="answers">
          I seem to spend my life telling people they are too late for good deal: How to explain this without it seeming like the usual sales talk? ... I don't know, but I will try to make this clear... You know, you are not buying this car. Only renting it for (probably 1 or 2 or 3 years). You are not stuck with it forever. So, you have no real risk. You are going to pay someone some money to run a car however you look at it. Then here is my tip; if you see damn good bargain, don't think too long, just jump. Often the fantastic bargain deals are only available for 1 or 2 days at a time. Then POOF! Gone! Just like Easyjet/Ryanair cheap flights. Physical stock is always limited, as cars cannot be made to appear by magic, there are only so many sat in corner of field. So be brave, grab a bargain and avoid me having to make phone calls to disappointed people who have left decision too late. Remember that you have to pass finance before I can reserve you a car, so allow time for that!
        </div>
      </div>

      <div>
        <input type="checkbox" id="question3" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question3" class="question">
          Tip: Maintenance charge is often rip off
        </label>
        <div class="answers">
          Do you need additional Maintenance Contract? I say NO! You see, most of my brand-new cars are on 2 or 3-year deals, so you should only need an oil and filter service (you won't need brake pads etc unless you drive like German idiot Schumacker). You just pay this service yourself, OK? Some service intervals (eg. Renault) now at 18,000 miles! You can have this small service done at a cheap VAT registered garage (applies to all but VW/Audi group contracts), just use quality parts. Your car is fully covered by the manufacturer warranty (use franchise dealer for this, free), and you get manufacturer's AA/RAC type cover. And when was the last time you had a puncture or needed a battery on a new car? So I don't think you need to pay more for "maintenance"! This is big profit area for other companies! Of course, they don't tell you that! However, if you really insist, I can add it to your car.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question4" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question4" class="question">
          Tip: Check delivery mileage
        </label>
        <div class="answers">
          Always make sure you check your car's mileage on delivery: Sometimes new car will be delivered on a car transporter, other times it will be driven to you. Either way, I always ask you check mileage on delivery. Write mileage on delivery sheet (before signing!!!) and keep a copy. At the end of contract, you can then subtract these miles from any "excess mileage" you may have incurred (extra miles over contract amount). This is easy if you have kept a copy of the delivery note. This is hard if you have lost it. For example, if a car is driven to you and has 300 miles on the clock, even at very low figure of 5p per mile this is worth £15. At a high figure of 15p per mile, this is worth £45! It's like getting a free tank of expensive British fuel!
        </div>
      </div>

      <div>
        <input type="checkbox" id="question5" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question5" class="question">
          Tip: Fit your own extras
        </label>
        <div class="answers">
          Buying extras can be like burning money: Most extras fitted onto cars don't seem to make difference to the resale price in 2-3 years. Metallic paint, leather and aircon actually do, but let's face it most cars I sell come with aircon and met paint, anyway. So, if you ask for quote to include extras, you can bet your life that it will mean you pay the whole cost of the extra thing, divided by the number of rentals. Well, my view is that if you're going to pay for the extra in full, you might as well own it... so why not just go out and buy it seperately? You'll probably get it cheaper than from a dealer, you do not give dealer/manufacturer profit and you have more choice. If, for example, you buy a nice set of alloys or a GPS navigation unit etc, at the end of the contract you can whipping the extra off the car and whipping it on ebay to get money back! I am damn clever, eh? Or fitting it on your next new car!
        </div>
      </div>

      <div>
        <input type="checkbox" id="question6" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question6" class="question">
          Tip: Don't get too excited about your car
        </label>
        <div class="answers">
          Try not to get TOO emotional about your new car: This is very difficult for some people to control because of the damn human nature. But try to look at your car as a simple consumer goods, like a fridge or microwave. Who would get excited by a microwave...? Because these cars are so very, very cheap, often dealer makes just a tiny profit. Almost like handling fee. Me too. I work on numbers of cars, like airline ticket consolidators sell tickets. So sometimes you must resign yourself to fact that dealer will look after a retail customer first. Your delivery might be slightly delayed because they are fussing over a damn retail customer (paying £1000's more than you), and you have to learn to relax. Most times these delays never happen, but sometimes they do, so I'm just preparing your brain and giving you tip. These deals were originally designed for car rental companies and car bodyshops... slowly they have become available to the public. So you save £££'s, just have patience!
        </div>
      </div>

      <div>
        <input type="checkbox" id="question7" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question7" class="question">
          Tip: Beware cheap rentals hiding large deposits
        </label>
        <div class="answers">
          Beware high first payments and low mileage deals: ANOTHER CHEATING LEASING COMPANY SCAM! Oh, I get very mad about this, but I cannot say this in my advertising or some big leasing companies complain to me that I slag them off... The industry standard for contract hire is a 1x, 3x or even 9x rental-initial-payment and 10k Miles per year. If everyone advertised this, you could easily compare the rental figures as the football field we are playing on would be flat. It would be easy! But some companies insist on using bigger initial payments and smaller mileage (eg 12+, or £5000+ and 5k miles per year) which mean that the rentals (they advertise) look smaller. This is rubbish and I think it is misleading. It means your total payment is probably higher. So you should be aware that this happens, and ask; "why do they do this?"
        </div>
      </div>

      <div>
        <input type="checkbox" id="question8" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question8" class="question">
          Tip: Send me loads of documents
        </label>
        <div class="answers">
          For a faster delivery, send me too many documents: This is quite true, most delays are caused by the finance company demanding documents. But it's not their fault. These days, in UK identity theft is common (not problem in China; we all look same, heheh), money laundering is common, and so is fraud. To proctect themselves, and you, against these problems the finance companies like lots of ID. There are many protecting regulations. Photographic and signature proving (new driving licence or passport), and address proving (recent 90 day or less old utility bill showing your name and address). A company may want to submit a VAT return (proof of trading) or latest signed accounts, and anyone can supply a current bank statement (you can blot out the figures if you are sensitive). Documents sent to me are uploaded and saved on a secure server, with security certificate. No documents are ever disclosed to anyone except designated finance company or dealer, no records are kept unless you want me to place a copy of your driving licence on electronic file for future, all originals are returned and copies shredded. You have the control to delete the files on my secure server. If I have extra info in my hand, then when the finance company request it, I can forward it instantly (usually speeding your car delivery up by at least 1 day). I am very damn clever, eh?
        </div>
      </div>
    </div>

    <footer id="contact"></footer>

    <?php include 'footer.php'; ?>

  </body>
</html>
